Main Scenery file
___________________________


Updating EGOD Scenery is now as simple as updating an aircraft:



The EGOD folder (containing, Airport,Objects&Terrain Folders)
should be placed in the following....


...flightgear/data/scenery (your scenery)




For any future updates this is the only folder you will have to replace
You will only have to click refresh on the airfield selection page after downloading 
the new scenery


A diagram showing the parking positions available is also in this folder



____________________________________________________________________________________________

If this is the first time downloading this scenery or you have only had V0.1 or V0.2 
then you now need to add this to your FG_SCENERY directory 
(exactly the same as you did for terrasync many moons ago)



	Open Flightgear to the aircraft selection page and click "prev"

		(This will open the page similar to one in the install.jpg  
		 that is above this readme file in the downloaded folder.)

	
	Click "Add"


	Follow the File path to where you have just put the EGOD Folder
		
		i.e.  C:/Program Files/Flightgear/data/scenery(your scenery)/EGOD/Models, all files


	This should add a line to your FG_Scenery list alongside the main directory and your terrasync directory

	
	
	The new line needs to be moved to the top of the list as shown in the image
		Do this by clicking the "up Arrow" on the right"
	
		(This means it takes priority over your other directories)

---------------------------------------------------------------------------------------------


---------------------------------------------------------------------------------------------


Thats the new scenery loaded!!!

	Simply go to the airfield selection page and click "refresh"
	When you now search for EGOD it will give you a list of parking positions to start from


______________________________________________________________________________________________



To get the arrestor cables working the  

EGOD_arrestor_cables.xml

has to be put alongside all of the other AI scenarios in....

	.....flightgear/data/AI


You can now select this as an AI scenario before running FG

_____________________________________________________________________________________________